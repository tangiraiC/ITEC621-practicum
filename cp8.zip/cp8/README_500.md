# CP8 Skills Extraction Pipeline

This project builds a multi-label machine learning pipeline for extracting professional skills from LinkedIn profile experience text using the 500-profile dataset.

## File Order

Run the files in this order:

1. `datapreparation_500.rmd`
2. `datapreprocessing_500.rmd`
3. `model_input_encoding_500.rmd`
4. `modeling_500.rmd`
5. `KSB621_CP8_Model_Evaluation_500.rmd`

## File Purpose

### 1. datapreparation_500.rmd

- loads raw experience and skills datasets
- engineers profile-level variables
- creates `profile_text`
- joins skills ground truth
- saves `model_ready_data.rds`

### 2. datapreprocessing_500.rmd

- cleans and normalizes text
- creates `profile_text_clean` and `profile_text_nostop`
- saves `clean_text_data.rds`

### 3. model_input_encoding_500.rmd

- splits the data into train, validation, and test sets
- identifies top skills from the training set
- creates TF-IDF feature matrices
- creates binary multi-label target matrices

### 4. modeling_500.rmd

- trains one-vs-rest GLMNET models
- trains one-vs-rest XGBoost models
- saves validation and test predictions

### 5. KSB621_CP8_Model_Evaluation_500.rmd

- computes micro precision, micro recall, micro F1
- computes macro F1
- computes subset accuracy
- exports evaluation tables

## Key Outputs

### Processed Data

- `data/processed/model_ready_data.rds`
- `data/processed/clean_text_data.rds`
- `data/processed/X_train.rds`
- `data/processed/X_valid.rds`
- `data/processed/X_test.rds`
- `data/processed/y_train.rds`
- `data/processed/y_valid.rds`
- `data/processed/y_test.rds`

### Models

- `models/glmnet_multilabel_models.rds`
- `models/xgb_multilabel_models.rds`

### Results

- `results/validation_results.csv`
- `results/test_results.csv`
- `results/per_skill_results.csv`

## Notes

- The project uses the 500 dataset as the modeling dataset.
- The skills file provides the ground-truth labels.
- The top 30 skills are modeled by default. This can be changed in `model_input_encoding_500.rmd`.

## Packages You May Need to Install

Run this once if needed:

```r
install.packages(c(
  "tidyverse",
  "stringr",
  "purrr",
  "here",
  "textclean",
  "stopwords",
  "rsample",
  "quanteda",
  "Matrix",
  "glmnet",
  "xgboost",
  "yardstick"
))
```
